import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { ComponentProps, useCallback, useEffect, useMemo, useState } from "react";
import {
  Alert,
  Image,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

import {
  Fonts,
  KhedmatPalette,
  Layout,
  Radius,
  Shadows,
  Spacing,
  Typography,
} from "../../constants/theme";
import { useCustomerAddresses } from "../../context/customer-address-context";
import { useCustomerProfile } from "../../context/customer-profile-context";
import { useLanguage } from "../../context/languagecontext";
import { useSession } from "../../context/session-context";
import { useSupabaseAuth } from "../../context/supabase-auth-context";
import { listOwnedProviderAccounts } from "../../repositories/provider-account-repository";
import { resolveProviderWorkspaceSwitch } from "../../services/provider-workspace-switch-resolver";

type IconName = ComponentProps<typeof Ionicons>["name"];

type LanguageName = "English" | "Dari" | "Pashto";

type ProfileMenuItem = {
  id: string;
  title: string;
  subtitle?: string;
  icon: IconName;
  badge?: string;
  destructive?: boolean;
  onPress: () => void;
};

export default function ProfileScreen() {
  const router = useRouter();
  const {
    language,
    t,
  } = useLanguage();
  const { profile } = useCustomerProfile();

  const {
    addresses,
  } = useCustomerAddresses();

  const {
    resetSession,
    enterProviderWorkspace,
    beginProviderRegistration,
  } = useSession();

  const {
    user,
    signOut,
  } = useSupabaseAuth();

  const activeLanguage = normalizeLanguage(language);

  const isRtl = activeLanguage === "Dari" || activeLanguage === "Pashto";

  const profileName =
    profile?.fullName || t("profileName");

  const profileInitials = getInitials(
    profileName,
  );

  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  const [
    isSwitchingWorkspace,
    setIsSwitchingWorkspace,
  ] = useState(false);

  const [
    hasProviderAccount,
    setHasProviderAccount,
  ] = useState<boolean | null>(
    null,
  );

  useEffect(() => {
    let isMounted = true;

    if (!user) {
      setHasProviderAccount(
        null,
      );

      return () => {
        isMounted = false;
      };
    }

    void listOwnedProviderAccounts(
      user.id,
    )
      .then((providers) => {
        if (!isMounted) {
          return;
        }

        setHasProviderAccount(
          providers.length > 0,
        );
      })
      .catch((error) => {
        console.warn(
          "Could not determine whether the customer owns provider accounts:",
          error,
        );

        if (isMounted) {
          /*
           * Unknown is intentionally represented as null.
           * The UI falls back to "Switch to Provider"
           * rather than falsely implying no provider
           * account exists.
           */
          setHasProviderAccount(
            null,
          );
        }
      });

    return () => {
      isMounted = false;
    };
  }, [user]);

  const handleSwitchToProvider =
    useCallback(
      async (): Promise<void> => {
      if (
        isSwitchingWorkspace
      ) {
        return;
      }

      if (!user) {
        Alert.alert(
          t(
            "switchWorkspaceFailedTitle",
          ),
          t(
            "switchWorkspaceFailedMessage",
          ),
        );

        return;
      }

      setIsSwitchingWorkspace(
        true,
      );

      try {
        const resolution =
          await resolveProviderWorkspaceSwitch(
            user.id,
          );

        if (
          resolution.destination ===
          "provider"
        ) {
          enterProviderWorkspace(
            resolution.providerId,
          );

          router.replace(
            "/(provider-tabs)",
          );

          return;
        }

        if (
          resolution.destination ===
          "provider-selection"
        ) {
          router.push(
            "/provider-account-selection",
          );

          return;
        }

        beginProviderRegistration();

        router.push(
          "/provider-welcome",
        );
      } catch (error) {
        console.error(
          "Failed to switch from customer to provider workspace:",
          error,
        );

        Alert.alert(
          t(
            "switchWorkspaceFailedTitle",
          ),
          t(
            "switchWorkspaceFailedMessage",
          ),
        );
      } finally {
        setIsSwitchingWorkspace(
          false,
        );
      }
    },
      [
        beginProviderRegistration,
        enterProviderWorkspace,
        isSwitchingWorkspace,
        router,
        t,
        user,
      ],
    );

  const accountItems = useMemo<ProfileMenuItem[]>(
    () => [
      {
        id: "switch-to-provider",
        title:
          hasProviderAccount === false
            ? t(
                "becomeProviderTitle",
              )
            : t(
                "switchToProviderTitle",
              ),
        subtitle:
          hasProviderAccount === false
            ? t(
                "becomeProviderSubtitle",
              )
            : t(
                "switchToProviderSubtitle",
              ),
        icon:
          hasProviderAccount === false
            ? "briefcase-outline"
            : "swap-horizontal-outline",
        onPress: () => {
          void handleSwitchToProvider();
        },
      },
      {
        id: "personal-information",
        title: t("personalInformationMenuTitle"),
        subtitle: t("personalInformationMenuSubtitle"),
        icon: "person-outline",
        onPress: () => {
          router.push("/account/personal-information");
        },
      },
      {
        id: "saved-addresses",
        title: t("savedAddressesMenuTitle"),
        subtitle: t("savedAddressesMenuSubtitle"),
        icon: "location-outline",
        badge: formatDigits(
          addresses.length.toString(),
          activeLanguage !== "English",
        ),
        onPress: () => {
          router.push("/account/saved-addresses");
        },
      },
      {
        id: "language",
        title: t("appLanguage"),
        subtitle: getLanguageDisplayName(activeLanguage),
        icon: "language-outline",
        onPress: () => {
          router.push({
            pathname: "/language",
            params: {
              source: "account",
            },
          });
        },
      },
    ],
    [
      activeLanguage,
      addresses.length,
      handleSwitchToProvider,
      hasProviderAccount,
      router,
      t,
    ],
  );

  const settingsItems = useMemo<ProfileMenuItem[]>(
    () => [
      {
        id: "notifications",
        title: t("notificationsMenuTitle"),
        subtitle: t("notificationsMenuSubtitle"),
        icon: "notifications-outline",
        onPress: () => {
          setNotificationsEnabled((current) => !current);
        },
      },
      {
        id: "privacy",
        title: t("privacySecurityMenuTitle"),
        subtitle: t("privacySecurityMenuSubtitle"),
        icon: "shield-checkmark-outline",
        onPress: () => {
          router.push("/account/privacy-security");
        },
      },
      {
        id: "payments",
        title: t("paymentsMenuTitle"),
        subtitle: t("paymentsMenuSubtitle"),
        icon: "card-outline",
        onPress: () => {
          router.push("/account/payments");
        },
      },
    ],
    [router, t],
  );

  const supportItems = useMemo<ProfileMenuItem[]>(
    () => [
      {
        id: "help",
        title: t("helpCenterMenuTitle"),
        subtitle: t("helpCenterMenuSubtitle"),
        icon: "help-circle-outline",
        onPress: () => {
          router.push("/account/help-center");
        },
      },
      {
        id: "contact-support",
        title: t("contactSupportMenuTitle"),
        subtitle: t("contactSupportMenuSubtitle"),
        icon: "headset-outline",
        onPress: () => {
          router.push("/account/contact-support");
        },
      },
      {
        id: "terms",
        title: t("termsPrivacyMenuTitle"),
        icon: "document-text-outline",
        onPress: () => {
          router.push("/account/terms-and-privacy");
        },
      },
    ],
    [router, t],
  );

  const handleLogout = () => {
    Alert.alert(
      t("logoutAction"),
      t("logoutConfirmation"),
      [
        {
          text: t(
            "cancelActionProfile",
          ),
          style: "cancel",
        },
        {
          text: t("logoutAction"),
          style: "destructive",
          onPress: () => {
            void (async () => {
              try {
                await signOut();

                resetSession();

                router.replace(
                  "/login",
                );
              } catch (error) {
                console.error(
                  "Failed to log out:",
                  error,
                );

                Alert.alert(
                  t(
                    "logoutFailedTitle",
                  ),
                  t(
                    "logoutFailedMessage",
                  ),
                );
              }
            })();
          },
        },
      ],
    );
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        <View style={styles.identityHeader}>
          <View style={styles.profileAvatar}>
            {profile?.avatarUri ? (
              <Image
                source={{ uri: profile.avatarUri }}
                style={styles.profileAvatarImage}
              />
            ) : (
              <Text style={styles.profileInitials}>
                {profileInitials}
              </Text>
            )}
          </View>

          <Text
  numberOfLines={2}
  style={[
    styles.profileName,
    directionStyle(isRtl),
    styles.centeredProfileName,
  ]}
>
  {profileName}
</Text>
        </View>

        <View style={styles.accountMenu}>
          {accountItems.map((item) => (
            <ProfileMenuItemCard
              key={item.id}
              item={item}
              isRtl={isRtl}
            />
          ))}
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, directionStyle(isRtl)]}>
            {t("settingsSectionTitle")}
          </Text>

          <View style={styles.menuList}>
            {settingsItems.map((item) => {
              if (item.id === "notifications") {
                return (
                  <ProfileToggleItem
                    key={item.id}
                    item={item}
                    selected={notificationsEnabled}
                    isRtl={isRtl}
                  />
                );
              }

              return (
                <ProfileMenuItemCard key={item.id} item={item} isRtl={isRtl} />
              );
            })}
          </View>
        </View>

        <ProfileSection
          title={t("supportSectionTitle")}
          items={supportItems}
          isRtl={isRtl}
        />

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, directionStyle(isRtl)]}>
            {t("accountActionsSectionTitle")}
          </Text>

          <Pressable
            accessibilityRole="button"
            accessibilityLabel={t("logoutAction")}
            onPress={handleLogout}
            style={({ pressed }) => [
              styles.logoutButton,
              pressed && styles.logoutButtonPressed,
            ]}
          >
            <View
              style={[
                styles.logoutButtonContent,
                {
                  flexDirection: isRtl ? "row-reverse" : "row",
                },
              ]}
            >
              <Ionicons
                name="log-out-outline"
                size={20}
                color={KhedmatPalette.error}
              />

              <Text style={[styles.logoutButtonText, directionStyle(isRtl)]}>
                {t("logoutAction")}
              </Text>
            </View>
          </Pressable>
        </View>

        <Text style={styles.versionText}>{t("appVersionLabel")}</Text>
      </ScrollView>
    </SafeAreaView>
  );
}
type ProfileSectionProps = {
  title: string;
  items: ProfileMenuItem[];
  isRtl: boolean;
};
function ProfileSection({ title, items, isRtl }: ProfileSectionProps) {
  return (
    <View style={styles.section}>
      <Text style={[styles.sectionTitle, directionStyle(isRtl)]}>{title}</Text>

      <View style={styles.menuList}>
        {items.map((item) => (
          <ProfileMenuItemCard key={item.id} item={item} isRtl={isRtl} />
        ))}
      </View>
    </View>
  );
}

type ProfileMenuItemCardProps = {
  item: ProfileMenuItem;
  isRtl: boolean;
};

function ProfileMenuItemCard({ item, isRtl }: ProfileMenuItemCardProps) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={item.title}
      onPress={item.onPress}
      style={({ pressed }) => [styles.menuCard, pressed && styles.cardPressed]}
    >
      <View
        style={[
          styles.menuContent,
          {
            flexDirection: isRtl ? "row-reverse" : "row",
          },
        ]}
      >
        <View
          style={[
            styles.menuIcon,
            item.destructive && styles.destructiveMenuIcon,
          ]}
        >
          <Ionicons
            name={item.icon}
            size={21}
            color={
              item.destructive ? KhedmatPalette.error : KhedmatPalette.blue500
            }
          />
        </View>

        <View
          style={[
            styles.menuCopy,
            {
              alignItems: isRtl ? "flex-end" : "flex-start",
            },
          ]}
        >
          <Text
            style={[
              styles.menuTitle,
              item.destructive && styles.destructiveMenuTitle,
              directionStyle(isRtl),
            ]}
          >
            {item.title}
          </Text>

          {item.subtitle ? (
            <Text style={[styles.menuSubtitle, directionStyle(isRtl)]}>
              {item.subtitle}
            </Text>
          ) : null}
        </View>

        {item.badge ? (
          <View style={styles.menuBadge}>
            <Text style={styles.menuBadgeText}>{item.badge}</Text>
          </View>
        ) : null}

        <Ionicons
          name={isRtl ? "chevron-back" : "chevron-forward"}
          size={18}
          color={KhedmatPalette.textMuted}
        />
      </View>
    </Pressable>
  );
}

type ProfileToggleItemProps = {
  item: ProfileMenuItem;
  selected: boolean;
  isRtl: boolean;
};

function ProfileToggleItem({ item, selected, isRtl }: ProfileToggleItemProps) {
  return (
    <Pressable
      accessibilityRole="switch"
      accessibilityLabel={item.title}
      accessibilityState={{
        checked: selected,
      }}
      onPress={item.onPress}
      style={({ pressed }) => [
        styles.menuCard,
        selected && styles.selectedToggleCard,
        pressed && styles.cardPressed,
      ]}
    >
      <View
        style={[
          styles.menuContent,
          {
            flexDirection: isRtl ? "row-reverse" : "row",
          },
        ]}
      >
        <View style={[styles.menuIcon, selected && styles.selectedMenuIcon]}>
          <Ionicons
            name={item.icon}
            size={21}
            color={selected ? KhedmatPalette.white : KhedmatPalette.blue500}
          />
        </View>

        <View
          style={[
            styles.menuCopy,
            {
              alignItems: isRtl ? "flex-end" : "flex-start",
            },
          ]}
        >
          <Text style={[styles.menuTitle, directionStyle(isRtl)]}>
            {item.title}
          </Text>

          {item.subtitle ? (
            <Text style={[styles.menuSubtitle, directionStyle(isRtl)]}>
              {item.subtitle}
            </Text>
          ) : null}
        </View>

        <View
          style={[styles.switchTrack, selected && styles.switchTrackSelected]}
        >
          <View
            style={[
              styles.switchThumb,
              selected && {
                alignSelf: isRtl ? "flex-start" : "flex-end",
              },
            ]}
          />
        </View>
      </View>
    </Pressable>
  );
}

function normalizeLanguage(language: string): LanguageName {
  if (language === "Dari") {
    return "Dari";
  }

  if (language === "Pashto") {
    return "Pashto";
  }

  return "English";
}

function getInitials(fullName: string): string {
  const nameParts = fullName
    .trim()
    .split(/\s+/)
    .filter(Boolean);

  if (nameParts.length === 0) {
    return "K";
  }

  return nameParts
    .slice(0, 2)
    .map((part) => part.charAt(0))
    .join("")
    .toUpperCase();
}

function directionStyle(isRtl: boolean) {
  return {
    textAlign: isRtl ? ("right" as const) : ("left" as const),

    writingDirection: isRtl ? ("rtl" as const) : ("ltr" as const),
  };
}

function formatDigits(value: string, localized: boolean): string {
  if (!localized) {
    return value;
  }

  const digits: Record<string, string> = {
    "0": "۰",
    "1": "۱",
    "2": "۲",
    "3": "۳",
    "4": "۴",
    "5": "۵",
    "6": "۶",
    "7": "۷",
    "8": "۸",
    "9": "۹",
  };

  return value.replace(/\d/g, (digit) => digits[digit] ?? digit);
}

function getLanguageDisplayName(language: LanguageName): string {
  if (language === "Dari") {
    return "دری";
  }

  if (language === "Pashto") {
    return "پښتو";
  }

  return "English";
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: KhedmatPalette.white,
  },

  scrollContent: {
    width: "100%",
    maxWidth: Layout.contentMaxWidth,
    alignSelf: "center",
    paddingHorizontal: Layout.screenPadding,
    paddingTop: Spacing.lg,
    paddingBottom: 130,
  },



  identityHeader: {
    width: "100%",
    alignItems: "center",
    marginTop: Spacing.sm,
    marginBottom: Spacing.sm,
    gap: Spacing.md,
  },

  profileAvatar: {
    width: 148,
    height: 148,
    borderRadius: Radius.pill,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: KhedmatPalette.navy900,
    borderWidth: 3,
    borderColor: KhedmatPalette.blue200,
    ...Shadows.small,
  },

  profileAvatarImage: {
    width: "100%",
    height: "100%",
    borderRadius: Radius.pill,
  },

  profileInitials: {
    fontFamily: Fonts.bold,
    color: KhedmatPalette.white,
    fontSize: 42,
    lineHeight: 50,
  },

  profileName: {
    ...Typography.sectionTitle,
    color: KhedmatPalette.textPrimary,
    fontSize: 23,
    lineHeight: 30,
  },

  centeredProfileName: {
    width: "100%",
    maxWidth: 320,
    textAlign: "center",
  },

  accountMenu: {
    width: "100%",
    marginTop: Spacing.xl,
    gap: Spacing.sm,
  },

  section: {
    width: "100%",
    marginTop: Spacing.xl,
    gap: Spacing.md,
  },

  sectionTitle: {
    ...Typography.sectionTitle,
    width: "100%",
    color: KhedmatPalette.textPrimary,
    fontSize: 20,
    lineHeight: 27,
  },

  menuList: {
    width: "100%",
    gap: Spacing.sm,
  },

  menuCard: {
    width: "100%",
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: KhedmatPalette.border,
    backgroundColor: KhedmatPalette.surface,
  },

  selectedToggleCard: {
    borderColor: KhedmatPalette.blue500,
    backgroundColor: "#F4FBFC",
  },

  menuContent: {
    width: "100%",
    minHeight: 76,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    alignItems: "center",
    gap: Spacing.md,
  },

  menuIcon: {
    width: 44,
    height: 44,
    flexShrink: 0,
    borderRadius: Radius.md,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: KhedmatPalette.surfaceSoft,
  },

  selectedMenuIcon: {
    backgroundColor: KhedmatPalette.blue500,
  },

  destructiveMenuIcon: {
    backgroundColor: KhedmatPalette.errorSoft,
  },

  menuCopy: {
    flex: 1,
    gap: 2,
  },

  menuTitle: {
    ...Typography.label,
    width: "100%",
    color: KhedmatPalette.textPrimary,
    fontSize: 16,
    lineHeight: 22,
  },

  destructiveMenuTitle: {
    color: KhedmatPalette.error,
  },

  menuSubtitle: {
    ...Typography.captionStyle,
    width: "100%",
    color: KhedmatPalette.textMuted,
  },

  menuBadge: {
    minWidth: 27,
    height: 27,
    paddingHorizontal: 7,
    borderRadius: Radius.pill,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: KhedmatPalette.surfaceSoft,
  },

  menuBadgeText: {
    ...Typography.captionStyle,
    color: KhedmatPalette.blue500,
    fontFamily: Fonts.bold,
  },

  switchTrack: {
    width: 46,
    height: 28,
    flexShrink: 0,
    borderRadius: Radius.pill,
    justifyContent: "center",
    paddingHorizontal: 3,
    backgroundColor: KhedmatPalette.border,
  },

  switchTrackSelected: {
    backgroundColor: KhedmatPalette.blue500,
  },

  switchThumb: {
    width: 22,
    height: 22,
    borderRadius: Radius.pill,
    backgroundColor: KhedmatPalette.white,
  },

  logoutButton: {
    width: "100%",
    minHeight: 52,
    borderRadius: Radius.lg,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "#E7B1AD",
    backgroundColor: KhedmatPalette.errorSoft,
  },

  logoutButtonPressed: {
    opacity: 0.8,
    transform: [
      {
        scale: 0.99,
      },
    ],
  },

  logoutButtonContent: {
    alignItems: "center",
    justifyContent: "center",
    gap: Spacing.sm,
  },

  logoutButtonText: {
    ...Typography.label,
    color: KhedmatPalette.error,
    fontFamily: Fonts.medium,
  },

  versionText: {
    ...Typography.captionStyle,
    width: "100%",
    marginTop: Spacing.section,
    color: KhedmatPalette.textMuted,
    textAlign: "center",
  },

  pressed: {
    opacity: 0.78,
  },

  cardPressed: {
    opacity: 0.88,
    transform: [
      {
        scale: 0.993,
      },
    ],
  },
});
